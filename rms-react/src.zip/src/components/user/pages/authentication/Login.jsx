import React from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import github from "../../../../assets/images/github.svg";
import google from "../../../../assets/images/google.svg";

const TOKEN_KEY = "token";
const USER_KEY = "user";

const LoginItem = () => {
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const email = e.target.email.value.trim();
    const password = e.target.password.value;

    try {
      const res = await axios.post("http://127.0.0.1:8000/auth/login", {
        email,
        password,
      });

      // Token có thể nằm trong nhiều key khác nhau tuỳ backend
      const token =
        res.data?.access_token ||
        res.data?.token ||
        res.data?.data?.token ||
        res.data?.data?.access_token;

      const user =
        res.data?.user ||
        res.data?.data?.user ||
        res.data?.data?.user_info ||
        null;

      if (!token || !user) {
        console.error("Login response:", res.data);
        alert("Login trả về thiếu token hoặc user. Kiểm tra API.");
        return;
      }

      // Lưu token + user vào localStorage
      localStorage.setItem(TOKEN_KEY, token);
      localStorage.setItem(USER_KEY, JSON.stringify(user));
      axios.defaults.headers.common["Authorization"] = `Bearer ${token}`;

      // Điều hướng theo role
      const role = Number(user.is_admin);
      if (role === 2) {
        navigate("/sysadmin"); // Giao diện System Admin
      } else if (role === 1) {
        navigate("/dashboard/employer"); // Giao diện Nhà tuyển dụng
      } else {
        navigate("/dashboard/candidate"); // Giao diện Ứng viên
      }
    } catch (err) {
      console.error("Login error:", err);
      alert("Đăng nhập thất bại. Vui lòng kiểm tra email/mật khẩu!");
    }
  };

  return (
    <section className="login">
      <div className="container">
        <div className="auth_div">
          <form onSubmit={handleSubmit}>
            <div className="form">
              <div>
                <input
                  type="email"
                  className="form-control"
                  name="email"
                  placeholder="user email"
                  required
                />
              </div>
              <div>
                <input
                  type="password"
                  className="form-control"
                  name="password"
                  placeholder="user password"
                  required
                />
              </div>
              <button type="submit" className="button">
                <span>Đăng nhập</span>
              </button>
              <div className="forgot">
                <Link to="/sign-up">Don't have any account?</Link>
                <Link to="/forgot-password">Forgot your password?</Link>
              </div>
              <div className="social">
                <img src={github} alt="github logo" />
                <img src={google} alt="google logo" />
              </div>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
};

export default LoginItem;
