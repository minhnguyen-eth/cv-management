import React from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import github from "../../../../assets/images/github.svg";
import google from "../../../../assets/images/google.svg";

const TOKEN_KEY = "token";

const LoginItem = () => {
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const email = e.target.email.value.trim();
    const password = e.target.password.value;

    try {
      const res = await axios.post(
        "http://127.0.0.1:8000/auth/login", // ⚠️ thường là /api/login (sửa lại nếu route của bạn khác)
        { email, password }
      );

      // Bắt các kiểu response phổ biến: {access_token}, {token}, {data:{token}}
      const token =
        res.data?.access_token ||
        res.data?.token ||
        res.data?.data?.token;

      if (!token) {
        console.error("Login response:", res.data);
        alert("Login trả về không có token. Kiểm tra API.");
        return;
      }

      // Lưu token + set default header cho axios
      localStorage.setItem(TOKEN_KEY, token);
      axios.defaults.headers.common["Authorization"] = `Bearer ${token}`;

      navigate("/dashboard");
    } catch (err) {
      console.error(err);
      alert("Đăng nhập thất bại. Vui lòng kiểm tra email/mật khẩu!");
    }
  };

  return (
    <section className="login">
      <div className="container">
        <div className="auth_div">
          <form onSubmit={handleSubmit}>
            <div className="form">
              <div>
                <input
                  type="email"
                  className="form-control"
                  name="email"
                  placeholder="user email"
                  required
                />
              </div>
              <div>
                <input
                  type="password"
                  className="form-control"
                  name="password"
                  placeholder="user password"
                  required
                />
              </div>
              <button type="submit" className="button">
                <span>Đăng nhập</span>
              </button>
              <div className="forgot">
                <Link to="/sign-up">Don't have any account?</Link>
                <Link to="/forgot-password">Forgot your password?</Link>
              </div>
              <div className="social">
                <img src={github} alt="github logo" />
                <img src={google} alt="google logo" />
              </div>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
};

export default LoginItem;
